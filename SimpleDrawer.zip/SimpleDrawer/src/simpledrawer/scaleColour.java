/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simpledrawer;

import java.awt.Color;

/**
 *
 * @author rajbir-dhillon
 */
public interface scaleColour {
    public Color scaleColour(Color c, float currentBrightness);
}
